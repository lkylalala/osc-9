/**
 * simulate eating
 */

#include <stdio.h>

void eating(int sleep_time) 
{
	//printf("eating for %d seconds\n",sleep_time);
	sleep(sleep_time);
}
