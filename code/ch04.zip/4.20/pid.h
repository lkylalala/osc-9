#define PID_MIN  	300
#define PID_MAX 	350

int pid_map[PID_MAX+1];

int last;	// last pid in use
